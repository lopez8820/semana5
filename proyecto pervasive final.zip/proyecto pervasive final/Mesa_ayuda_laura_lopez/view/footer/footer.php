<?php
    if ($_SESSION["rol_id"]==1){
        ?>

<br><br><br><br><br><br><br><br>
         <!-- Footer -->
<footer class="card-primary card-footer">

<!-- Copyright -->
<div class="page-content">

<div class="container-fluid">
			<div class="row">
				<div class="col-xl-12">
					<div class="row">
						<div class="col-sm-4">
	                        
                        <div class="user-card-row">
								<div class="number" id="lbltotal"></div>
	                                <div class="caption"><div>Copyright © 2022 Pervavive Software</div></div>
	                            </div>
	                       
	                    </div>
						<div class="col-sm-4">
                        <div class="causer-card-rowrd">
	                            
	                                <div class="number" id="lbltotalabierto"></div>
	                                <div class="caption"><div>Gaes 8- Analisis y diseno de sistemas de informacion </div></div>
	                            </div>
	                       
	                    </div>
						<div class="col-sm-4">
	                      
	                            <div class="user-card-row">
	                                <div class="number" id="lbltotalcerrado"></div>
	                                <div class="caption"><div>Yimer Cortes Ariza - Luis Gutierrez Hayek</div></div>
	                            </div>
	                      
	                    </div>
					</div>
				</div>
                </div></div>


<!-- Copyright -->

</footer>
<!-- Footer -->
        <?php



    }else{
        ?>



          <section>
<!-- Footer -->

<br><br><br><br><br><br><br><br>
<footer class="card-primary card-footer">

<div class="page-content">
			<div class="row">
				<div class="col-xl-12">
					<div class="row">
						<div class="col-sm-4">
	                       
	                            <div class="user-card-row">
								
	                                <div class="caption"><div>Copyright © 2022 Pervavive Software</div></div>
	                            </div>
	                       
	                    </div>
						<div class="col-sm-4">
	                       
                        <div class="user-card-row">
	                               
	                                <div class="caption"><div>Gaes 8-Analisis y diseno de sistemas de informacion</div></div>
	                            </div>
	                       
	                    </div>
						<div class="col-sm-4">
	                        
                            <div class="user-card-row">
	                               
	                                <div class="caption"><div>Yimer Cortes Ariza - Luis Gutierrez Hayek</div></div>
	                            </div>
	                      
	                    </div>
					</div>
				</div>
				</div>	


</footer>
<!-- Footer -->
        <?php
    }
?>

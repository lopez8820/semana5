<?php
 function insertar_datos($title,$description){
 		global $conn;
 	$sentencia = "insert into task (title,description) values ('$title','$description')";
 	$ejecutar = mysqli_query($conn,$sentencia);
 	return $ejecutar;
 }
?>
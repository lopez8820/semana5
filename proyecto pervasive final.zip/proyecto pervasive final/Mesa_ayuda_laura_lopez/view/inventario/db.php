<?php


$conn = mysqli_connect(
  'localhost',
  'root',
  '',
  'php_mysql_crud'
) or die(mysqli_error($mysqli));

?>

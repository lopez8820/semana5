<?php
// Inicia una nueva sesión o reanuda la existente para mantener la información de usuario entre páginas
    session_start();
    
    class Conectar{
        protected $dbh;
 // Definición de la clase Conectar para manejar conexiones a la base de datos
  // Propiedad protegida para almacenar la instancia de conexión a la base de datos
        protected function Conexion(){
            try {
                // Intenta conectarse a la base de datos usando la configuración de producción
				$conectar = $this->dbh = new PDO("mysql:local=localhost:90;dbname=andercode_helpdesk","root","");
                //Produccion
				return $conectar;
			} catch (Exception $e) {
				print "¡Error BD!: " . $e->getMessage() . "<br/>";
				die();
			}
        }
 // Método público para configurar la codificación de caracteres de la conexión a UTF-8
        public function set_names(){
			return $this->dbh->query("SET NAMES 'utf8'");
        }

        public static function ruta(){
            //Local
			return "http://localhost:90/PERSONAL_HelpDesk/";
            //Produccion
            //return "https://www.pervasivesofwae.com.co/";
		}

    }
?>
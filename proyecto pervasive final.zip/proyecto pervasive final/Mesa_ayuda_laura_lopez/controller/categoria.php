<?php
// Incluir archivos necesarios para la conexión a la base de datos y definición del modelo 'Categoria'
    require_once("../config/conexion.php");
    require_once("../models/Categoria.php");
    $categoria = new Categoria();
// Manejo de una acción especificada por el parámetro 'op' en la URL
    switch($_GET["op"]){
        case "combo":
            $datos = $categoria->get_categoria();
            $html="";
            $html.="<option label='Seleccionar'></option>";
            // Verifica si los datos son un array y no están vacíos
            if(is_array($datos)==true and count($datos)>0){
                foreach($datos as $row)
// Añade una opción al select por cada categoría encontrada en la base de datos

                {
                    $html.= "<option value='".$row['cat_id']."'>".$row['cat_nom']."</option>";
                }
                echo $html;
            }
        break;
    }
?>
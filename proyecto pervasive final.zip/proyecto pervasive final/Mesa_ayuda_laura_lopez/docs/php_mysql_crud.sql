-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-06-2022 a las 02:02:02
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `php_mysql_crud`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `task`
--

INSERT INTO `task` (`id`, `title`, `description`, `created_at`) VALUES
(493, 'hp gamer', 'eeeeee', '2022-05-11 04:06:34'),
(520, 'hp portatil gamer 1080', '32432432n54', '2022-06-03 02:11:37'),
(521, 'hp gamer', 'eeeeee', '2022-06-03 02:31:39'),
(529, 'hp gamer', 'eeeeee', '2022-06-03 22:41:14'),
(530, 'accer', 'pioui', '2022-06-03 22:41:14'),
(531, 'hp', 'prirere', '2022-06-03 22:41:14'),
(532, 'asdsad', 'sdasdsa', '2022-06-03 22:41:14'),
(533, 'asdsadas', 'sadsad', '2022-06-03 22:41:14'),
(534, 'ffff', 'fffff', '2022-06-03 22:41:14'),
(535, 'hp gamer', 'eeeeee', '2022-06-08 01:50:21'),
(536, 'accer', 'pioui', '2022-06-08 01:50:21'),
(537, 'hp', 'prirere', '2022-06-08 01:50:21'),
(538, 'asdsad', 'sdasdsa', '2022-06-08 01:50:21');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=541;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
